var linkset=new Array()
//SPECIFY MENU SETS AND THEIR LINKS
linkset[0]='<div class="menuitems"><p style="font:bold 13px;" align=center><i>Zdzis�aw Papir</div>'
linkset[0]+='<div class="menuitems"><p style="font:bold 13px;" align=center><i>Podstawy modulacji i detekcji.<br>Cz. 2<br>Wyd. 2 <hr size=1></div>'
linkset[0]+='<div class="menuitems"></div>'
linkset[0]+='<div class="menuitems"><p align=left>Instytucja sprawcza:</div>'
linkset[0]+='<div class="menuitems"><p style="font:12px;" align=center>Akademia G�rniczo-Hutnicza<br>im. St. Staszica w Krakowie<br>Biblioteka G��wna</div>'
linkset[0]+='<div class="menuitems"><p align=left>Adres wydawniczy:</div>'
linkset[0]+='<div class="menuitems"><p style="font:12px;" align=center>Krak�w : BG AGH, 2005</div>'
linkset[0]+='<div class="menuitems">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=mailto:kawula@bg.agh.edu.pl>Anna Matuszyk</a></div>'
linkset[0]+='<div class="menuitems">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=mailto:jacekr@hplib.bg.agh.edu.pl>Jacek Rzepczy�ski</a></div>'
linkset[0]+='<div class="menuitems" align=left>Opracowanie formalne: <a class=dig href=mailto:kawula@bg.agh.edu.pl>Anna Matuszyk</a></div>'


