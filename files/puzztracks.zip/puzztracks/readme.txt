MIDI files from PuzzPower 2.0 by Erwin Bergervoet (GamesLab)
